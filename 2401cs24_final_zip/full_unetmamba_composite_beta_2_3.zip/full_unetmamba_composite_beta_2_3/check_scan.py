"""Check recurrence and gradients; CUDA mode also measures fallback kernel overhead."""
import sys,json,time
import torch
from mamba_backend import reference_scan,load_mamba
torch.set_num_threads(4);torch.manual_seed(7)
device='cuda' if '--cuda' in sys.argv else 'cpu'
u=torch.randn(2,8,137,device=device,requires_grad=True);delta=torch.randn_like(u,requires_grad=True);A=(-torch.rand(8,3,device=device)).requires_grad_();B=torch.randn(2,4,3,137,device=device,requires_grad=True);C=torch.randn_like(B,requires_grad=True);D=torch.randn(8,device=device,requires_grad=True);bias=torch.randn_like(D,requires_grad=True)
args=(u,delta,A,B,C,D,bias);y=reference_scan(*args,True)
dt=torch.nn.functional.softplus(delta+bias[None,:,None]);state=torch.zeros(2,8,3,device=device);ys=[]
bb=B.repeat_interleave(2,1);cc=C.repeat_interleave(2,1)
for i in range(137):
    state=torch.exp(dt[:,:,i,None]*A[None])*state+dt[:,:,i,None]*u[:,:,i,None]*bb[:,:,:,i];ys.append((state*cc[:,:,:,i]).sum(2)+u[:,:,i]*D)
expected=torch.stack(ys,-1);assert torch.allclose(y,expected,atol=1e-5,rtol=1e-5)
g1=torch.autograd.grad(y.sum(),args,retain_graph=True);g2=torch.autograd.grad(expected.sum(),args,retain_graph=True)
assert all(torch.allclose(a,b,atol=2e-5,rtol=2e-5) for a,b in zip(g1,g2))
result=dict(label='UNetMamba scan correctness check; synthetic tensors',reference_values_and_gradients='passed',device=device)
if device=='cuda':
    vm=load_mamba('cuda');import sys
    core=sys.modules['unetmamba_model.classification.models.vmamba'].SelectiveScanCore
    yy=core.apply(*args,True,1,1,True);gg=torch.autograd.grad(yy.sum(),args,retain_graph=True)
    assert torch.allclose(y,yy,atol=1e-4,rtol=1e-4) and all(torch.allclose(a,b,atol=1e-4,rtol=1e-4) for a,b in zip(g1,gg))
    times={}
    for name,fn in [('cuda_core',lambda:core.apply(*args,True,1,1,True)),('reference',lambda:reference_scan(*args,True))]:
        measured=[]
        for i in range(35):
            torch.cuda.synchronize();t=time.perf_counter();v=fn();torch.autograd.grad(v.sum(),args);torch.cuda.synchronize()
            if i>=5:measured.append(time.perf_counter()-t)
        times[name]=sum(measured)/len(measured)
    result.update(cuda_values_and_gradients='passed',tiny_kernel_seconds_measured=times,tiny_kernel_fallback_slowdown_measured=times['reference']/times['cuda_core'],limitation='Tiny recurrence benchmark, not full-model slowdown; use full reference model bench for that.')
print(json.dumps(result,indent=2))
