# UNetMamba composite trial: beta = 2/3

Loss = (1/3) cross-entropy + (2/3) soft Dice. Train for 10 epochs from scratch.
This is one predefined weight-search candidate, not an optimal-weight claim.
Compare its validation mIoU with the beta=1/3 candidate and individual losses.

Upload the entire folder and attach the same full Potsdam dataset. Open the
single kaggle_demo.ipynb, enable Internet and GPU, then run cells in order.
Set RUN_TRAINING=True. Keep test prediction disabled while selecting weights.

Included: account-independent dataset discovery; folder or manifest.json path
overrides; nested TIFF resolution; exclusions of 4_12 and 6_7 (16/6/14 split);
CUDA selective-scan compatibility fixes; dependency, scan and model checks;
smoke test; beta/10-epoch verification; progress reporting and saved logs.

Same seed 20261110, batch 2, patch 512, AdamW lr=1e-4, weight decay=.01,
constant schedule, float32 and random initialization as previous Mamba runs.
Only the main head contributes. CE averages valid pixels; Dice averages all
six classes using pooled batch/spatial dimensions and smoothing 1e-6.
Target 255 is ignored. Prior CE used 20 epochs; disclose the different budget.

For prediction after losing notebook variables, set CHECKPOINT_PATH explicitly
to this trial's best.pt. A missing TRAIN_CHECKPOINT variable gives a clear
checkpoint prompt rather than NameError. No exact training resume is supported.
Do not rerun training to recover prediction outputs.

Preserve best.pt, last.pt, history.json, report.json, run_config.json and logs.
The config records candidate weights and status. The second trial and automated
winner selection are separate steps; this folder does not claim a completed search.
