"""Potsdam RGB patch loader and six-class loss (no height placeholders).

Required root/manifest.json example:
{"tiles": [{"tile_id": "2_10", "split": "train",
            "image": "2_Ortho_RGB/2_Ortho_RGB/top_potsdam_2_10_RGB.tif",
            "mask": "5_Labels_all/top_potsdam_2_10_label.tif"}]}

Assign original tiles to train/validation/test before cropping. Paths are
relative to root. RGB masks are the default; prepared one-band masks require
label_encoding="class_ids". Set ignore_black=true for RGB noBoundary masks.
Test records may omit masks. No automatic spatial split is invented.

Samples are dictionaries with image/mask tensors and tile/window coordinates.
Default normalization is ImageNet RGB; override mean/std to match the encoder.
Unreferenced labels are assumed pixel-aligned after dimension checks; verify
their overlays separately. Coordinates describe patches before augmentation.
"""
import json
import random
import re
from pathlib import Path

import numpy as np
import rasterio
from rasterio.windows import Window
import torch
from torch.utils.data import Dataset

LABEL = "Potsdam RGB; six-class semantic segmentation"
CLASS_NAMES = ("impervious_surface", "building", "low_vegetation", "tree", "car", "clutter")
PALETTE = np.array([(255, 255, 255), (0, 0, 255), (0, 255, 255),
                    (0, 255, 0), (255, 255, 0), (255, 0, 0)], dtype=np.uint8)
NUM_CLASSES = 6
IGNORE_INDEX = 255


def decode_mask(values, *, encoding="rgb", ignore_black=False):
    """Decode band-first uint8 labels, rejecting unexpected colors or IDs."""
    if values.dtype != np.uint8:
        raise ValueError("Labels must be uint8")
    if encoding == "class_ids":
        if values.ndim != 3 or values.shape[0] != 1:
            raise ValueError("class_ids masks require one band")
        mask = values[0].copy()
        if not np.isin(mask, [0, 1, 2, 3, 4, 5, IGNORE_INDEX]).all():
            raise ValueError("Unknown class ID")
        return mask
    if encoding != "rgb" or values.ndim != 3 or values.shape[0] != 3:
        raise ValueError("RGB masks require three bands")
    mask = np.full(values.shape[1:], IGNORE_INDEX, dtype=np.uint8)
    known = np.zeros(mask.shape, dtype=bool)
    for class_id, color in enumerate(PALETTE):
        match = np.all(values == color[:, None, None], axis=0)
        mask[match] = class_id
        known |= match
    if ignore_black:
        known |= np.all(values == 0, axis=0)
    if not known.all():
        unknown = np.unique(values[:, ~known].T, axis=0)[:8].tolist()
        raise ValueError(f"Unknown label colors: {unknown}; black requires ignore_black=true")
    return mask


def _tile_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d+_\d+", value):
        raise ValueError(f"Invalid Potsdam tile ID: {value!r}")
    return "_".join(str(int(part)) for part in value.split("_"))


# Mapping is generated before the training subprocess starts.
_map_file = Path(__file__).with_name('dataset_paths.json')
_path_map = json.loads(_map_file.read_text()) if _map_file.is_file() else {}
EXCLUDED_TRAINING_TILES = ('4_12', '6_7')


def _path(root, value, tile_id):
    if not isinstance(value, str) or Path(value).is_absolute():
        raise ValueError("Manifest paths must be relative to dataset root")
    if str(root) == _path_map.get('data_root'):
        value = _path_map.get('overrides', {}).get(value, value)
    path = (root / value).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Manifest path escapes dataset root")
    match = re.search(r"potsdam_(\d+_\d+)_", path.name, re.IGNORECASE)
    if match and _tile_id(match[1]) != tile_id:
        raise ValueError(f"Filename and tile ID disagree: {path.name}")
    return path


class Tiles(Dataset):
    def __init__(self, root, split="train", augment=False, patch_size=512,
                 stride=None, mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)):
        self.root = Path(root).resolve()
        self.manifest = json.loads((self.root / "manifest.json").read_text(encoding="utf-8"))
        if split not in ("train", "validation", "test"):
            raise ValueError("Unknown split")
        if augment and split != "train":
            raise ValueError("Only training may be augmented")
        stride = patch_size if stride is None else stride
        if not isinstance(patch_size, int) or not isinstance(stride, int) or not 0 < stride <= patch_size:
            raise ValueError("Require integer 0 < stride <= patch_size")
        if split != "train" and stride != patch_size:
            raise ValueError("Evaluation patches must not overlap")
        self.patch_size, self.augment = patch_size, augment
        self.mean, self.std = np.asarray(mean, dtype=np.float32), np.asarray(std, dtype=np.float32)
        if (self.mean.shape != (3,) or self.std.shape != (3,) or
                not np.isfinite(self.mean).all() or not np.isfinite(self.std).all() or (self.std <= 0).any()):
            raise ValueError("mean/std require three finite values with positive std")
        entries = self.manifest.get("tiles")
        if not isinstance(entries, list) or not entries:
            raise ValueError("Manifest requires a nonempty tiles list")
        seen_ids, seen_images, seen_masks = set(), set(), set()
        self.records, self.patches = [], []
        for entry in entries:
            record = dict(entry)
            tile_id = _tile_id(record["tile_id"])
            if tile_id in EXCLUDED_TRAINING_TILES:
                if record.get('split') != 'train':
                    raise ValueError('Excluded tile must belong to training')
                continue
            if record.get("split") not in ("train", "validation", "test"):
                raise ValueError(f"Missing/invalid split for {tile_id}")
            image = _path(self.root, record["image"], tile_id)
            if re.search(r"_(IRRG|RGBIR)\.tiff?$", image.name, re.IGNORECASE):
                raise ValueError("RGB-only loader requires the RGB product")
            mask = _path(self.root, record["mask"], tile_id) if record.get("mask") else None
            if tile_id in seen_ids or image in seen_images or (mask is not None and mask in seen_masks):
                raise ValueError("Duplicate tile or reused image/mask: split leakage risk")
            seen_ids.add(tile_id)
            seen_images.add(image)
            if mask is not None:
                seen_masks.add(mask)
            if record["split"] != "test" and mask is None:
                raise ValueError(f"Labels missing for {tile_id}")
            encoding = record.get("label_encoding", "rgb")
            if encoding not in ("rgb", "class_ids"):
                raise ValueError("Unknown label_encoding")
            if not isinstance(record.get("ignore_black", False), bool):
                raise ValueError("ignore_black must be a JSON boolean")
            if record["split"] != split:
                continue  # Do not open rasters from other splits.
            with rasterio.open(image) as src:
                if src.count != 3 or any(dtype != "uint8" for dtype in src.dtypes):
                    raise ValueError(f"Expected three-band uint8 RGB: {image}")
                height, width = src.height, src.width
                if mask is not None:
                    with rasterio.open(mask) as ref:
                        if ((ref.height, ref.width) != (height, width) or
                                ref.count != (3 if encoding == "rgb" else 1) or
                                any(dtype != "uint8" for dtype in ref.dtypes)):
                            raise ValueError(f"Mask shape/bands/dtype mismatch: {mask}")
                        if src.crs is not None and ref.crs is not None and src.crs != ref.crs:
                            raise ValueError(f"Image/mask CRS mismatch: {tile_id}")
                        if (not src.transform.is_identity and not ref.transform.is_identity and
                                not src.transform.almost_equals(ref.transform, precision=1e-8)):
                            raise ValueError(f"Image/mask transform mismatch: {tile_id}")
            record.update(tile_id=tile_id, image=image, mask=mask, height=height, width=width)
            record_index = len(self.records)
            self.records.append(record)
            for row in range(0, height, stride):
                for col in range(0, width, stride):
                    self.patches.append((record_index, row, col))
        if not self.records:
            raise ValueError(f"No tiles assigned to {split}")

    def __len__(self):
        return len(self.patches)

    def __getitem__(self, index):
        record_index, row, col = self.patches[index]
        record = self.records[record_index]
        height = min(self.patch_size, record["height"] - row)
        width = min(self.patch_size, record["width"] - col)
        window = Window(col, row, width, height)
        with rasterio.open(record["image"]) as src:
            image = src.read(window=window).astype(np.float32) / 255.0
            valid = np.all(src.read_masks(window=window) > 0, axis=0)
        image = (image - self.mean[:, None, None]) / self.std[:, None, None]
        image[:, ~valid] = 0
        x = np.zeros((3, self.patch_size, self.patch_size), dtype=np.float32)
        x[:, :height, :width] = image
        y = np.full((self.patch_size, self.patch_size), IGNORE_INDEX, dtype=np.uint8)
        if record["mask"] is not None:
            with rasterio.open(record["mask"]) as src:
                values = src.read(window=window)
                label_valid = np.all(src.read_masks(window=window) > 0, axis=0)
            # Decode only valid data; nodata is restored as ignore afterward.
            values[:, ~label_valid] = PALETTE[0, :, None] if values.shape[0] == 3 else 0
            mask = decode_mask(values, encoding=record.get("label_encoding", "rgb"),
                               ignore_black=record.get("ignore_black", False))
            mask[~valid | ~label_valid] = IGNORE_INDEX
            y[:height, :width] = mask
        if self.augment:
            if random.random() < 0.5:
                x, y = x[:, :, ::-1], y[:, ::-1]
            if random.random() < 0.5:
                x, y = x[:, ::-1, :], y[::-1, :]
        return dict(image=torch.from_numpy(x.copy()), mask=torch.from_numpy(y.copy()).long(),
                    tile_id=record["tile_id"], row=row, col=col,
                    valid_height=height, valid_width=width,
                    tile_height=record["height"], tile_width=record["width"])


def dice_loss(logits, y):
    """Six-class soft Dice, batch/spatial pooling, smoothing 1e-6; ignores 255."""
    if isinstance(logits, (tuple, list)):
        logits = logits[0]
    if y.ndim != 3 or logits.shape != (y.shape[0], NUM_CLASSES, *y.shape[-2:]):
        raise ValueError("Expected logits [B,6,H,W] and targets [B,H,W]")
    if not bool((y != IGNORE_INDEX).any()):
        raise ValueError("No supervised pixels in batch")
    valid = y != IGNORE_INDEX
    if bool(((y[valid] < 0) | (y[valid] >= NUM_CLASSES)).any()):
        raise ValueError('Target class outside 0..5')
    target = torch.nn.functional.one_hot(y.masked_fill(~valid, 0).long(), NUM_CLASSES)
    target = target.permute(0, 3, 1, 2).float() * valid[:, None]
    probabilities = torch.softmax(logits.float(), dim=1) * valid[:, None]
    dims = (0, 2, 3)
    intersection = (probabilities * target).sum(dims)
    denominator = probabilities.sum(dims) + target.sum(dims)
    dice = (2 * intersection + 1e-6) / (denominator + 1e-6)
    return 1 - dice.mean()


def ce_loss(logits, y):
    """Main-head cross entropy; auxiliary supervision is a caller decision."""
    if isinstance(logits, (tuple, list)):
        logits = logits[0]
    if y.ndim != 3 or logits.shape != (y.shape[0], NUM_CLASSES, *y.shape[-2:]):
        raise ValueError("Expected logits [B,6,H,W] and targets [B,H,W]")
    if not bool((y != IGNORE_INDEX).any()):
        raise ValueError("No supervised pixels in batch")
    return torch.nn.functional.cross_entropy(logits.float(), y, ignore_index=IGNORE_INDEX)


def loss_fn(logits, y):
    """Fixed search trial: (1/3) CE + (2/3) Dice; main head only."""
    return (1 / 3) * ce_loss(logits, y) + (2 / 3) * dice_loss(logits, y)
