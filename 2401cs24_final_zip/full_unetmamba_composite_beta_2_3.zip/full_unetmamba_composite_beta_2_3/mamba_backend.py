"""Adapters around pinned official implementations. No pretrained weights fetched."""
import sys,types,importlib.util,copy
from pathlib import Path
import torch
from torch import nn
P=Path(__file__).resolve().parent
def source_module(name,path,text=None):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    exec(compile(text if text is not None else path.read_text(encoding='utf-8'),str(path),'exec'),module.__dict__)
    return module
def reference_scan(u,delta,A,B,C,D=None,bias=None,softplus=True,*unused):
    """Exact real-valued grouped recurrence, chunked associative prefix scan.
    Pure PyTorch fallback. Same recurrence; different execution backend and cost.
    """
    from torch.utils.checkpoint import checkpoint
    dtype=u.dtype;u,delta,A,B,C=[v.float() for v in (u,delta,A,B,C)]
    if bias is not None:delta=delta+bias.float()[None,:,None]
    if softplus:delta=torch.nn.functional.softplus(delta)
    batch,channels,length=u.shape;groups=B.shape[1];state=A.shape[1];per=channels//groups
    carry=u.new_zeros(batch,channels,state);outs=[]
    def chunk(uu,dd,aa,bb,cc,carry):
        bb=bb.repeat_interleave(per,dim=1);cc=cc.repeat_interleave(per,dim=1)
        pa=torch.exp(dd[:,:,None,:]*aa[None,:,:,None]);pb=dd[:,:,None,:]*uu[:,:,None,:]*bb
        offset=1
        while offset<uu.shape[-1]:
            pb=torch.cat([pb[...,:offset],pb[...,offset:]+pa[...,offset:]*pb[...,:-offset]],-1)
            pa=torch.cat([pa[...,:offset],pa[...,offset:]*pa[...,:-offset]],-1);offset*=2
        states=pb+pa*carry[:,:,:,None]
        return (states*cc).sum(2),states[:,:,:,-1]
    for start in range(0,length,64):
        sl=slice(start,start+64);args=(u[:,:,sl],delta[:,:,sl],A,B[:,:,:,sl],C[:,:,:,sl],carry)
        out,carry=checkpoint(chunk,*args,use_reentrant=False) if torch.is_grad_enabled() and any(x.requires_grad for x in args) else chunk(*args)
        outs.append(out)
    result=torch.cat(outs,-1)
    if D is not None:result=result+u*D.float()[None,:,None]
    return result.to(dtype)
class RefScan:
    apply=staticmethod(reference_scan)
def load_mamba(backend):
    root=P/'vendor/UNetMamba';sys.path.insert(0,str(root))
    # Load qualified modules without executing the unrelated classification registry.
    for name,path in [('unetmamba_model',root/'unetmamba_model'),('unetmamba_model.classification',root/'unetmamba_model/classification'),('unetmamba_model.classification.models',root/'unetmamba_model/classification/models')]:
        if name not in sys.modules:
            m=types.ModuleType(name);m.__path__=[str(path)];sys.modules[name]=m
    path=root/'unetmamba_model/classification/models/vmamba.py';text=path.read_text()
    start=text.index('try:\n    from .csm_triton');end=text.index('# pytorch cross scan',start)
    # Default v2 uses the official PyTorch CrossScan/CrossMerge, not Triton paths.
    text=text[:start]+'CrossScanTriton = CrossMergeTriton = CrossScanTriton1b1 = None\n\n'+text[end:]
    vm=source_module('unetmamba_model.classification.models.vmamba',path,text)
    if backend=='reference':vm.SelectiveScanCore=RefScan
    else:
        import selective_scan_cuda_core  # fail explicitly if compile/install did not work
    return source_module('potsdam_unetmamba',root/'unetmamba_model/models/UNetMamba.py')
