import json
import math
from pathlib import Path
import unittest
import torch
from data import loss_fn, ce_loss, dice_loss
from run import validate_task_config


class CompositeTests(unittest.TestCase):
    def test_uniform_predictions(self):
        logits = torch.zeros(1, 6, 1, 6, requires_grad=True)
        target = torch.arange(6).reshape(1, 1, 6)
        value = loss_fn(logits, target)
        self.assertAlmostEqual(value.item(), (1 / 3) * math.log(6) + (2 / 3) * (5 / 6), places=5)
        value.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertGreater(logits.grad.abs().sum().item(), 0)

    def test_weight_and_budget(self):
        cfg = json.loads(Path(__file__).with_name('config.json').read_text())
        validate_task_config(cfg)
        self.assertEqual(cfg['epochs'], 10)
        cfg['composite_beta'] = 1 / 3
        with self.assertRaises(ValueError):
            validate_task_config(cfg)

    def test_ignored_pixel_and_auxiliary_output(self):
        logits = torch.randn(1, 6, 1, 3, requires_grad=True)
        target = torch.tensor([[[0, 1, 255]]])
        value = loss_fn((logits, torch.tensor(float('nan'))), target)
        expected = (1 / 3) * ce_loss(logits, target) + (2 / 3) * dice_loss(logits, target)
        self.assertTrue(torch.allclose(value, expected))
        value.backward()
        self.assertEqual(logits.grad[..., 2].abs().sum().item(), 0)
