"""Explicit full-model forward/backward check; no dataset or checkpoint needed."""
import argparse
import json
import time
import torch
from model import build_model, main_logits
from data import loss_fn


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--backend', choices=['cuda', 'reference'], default='cuda')
    parser.add_argument('--device', choices=['cuda', 'cpu'], default='cuda')
    parser.add_argument('--size', type=int, default=256)
    args = parser.parse_args()
    if args.size < 64 or args.size % 32:
        parser.error('size must be a multiple of 32 and at least 64')
    torch.set_num_threads(4)
    torch.manual_seed(7)
    started = time.perf_counter()
    model = build_model(backend=args.backend).to(args.device).train()
    x = torch.randn(1, 3, args.size, args.size, device=args.device)
    target = torch.randint(0, 6, (1, args.size, args.size), device=args.device)
    logits = main_logits(model(x))
    assert logits.shape == (1, 6, args.size, args.size), logits.shape
    loss = loss_fn(logits, target)
    assert torch.isfinite(loss)
    loss.backward()
    grads = [p.grad for p in model.parameters() if p.grad is not None]
    assert grads and all(torch.isfinite(g).all() for g in grads)
    assert any(p.grad is not None and bool(p.grad.abs().sum() > 0)
               for p in model.encoder.stem.parameters())
    model.eval()
    with torch.no_grad():
        prediction = main_logits(model(x))
    assert prediction.shape == logits.shape and torch.isfinite(prediction).all()
    print(json.dumps(dict(status='passed', backend=args.backend, device=args.device,
                         shape=list(logits.shape), loss=float(loss.detach()),
                         seconds=time.perf_counter()-started), indent=2))


if __name__ == '__main__':
    main()
