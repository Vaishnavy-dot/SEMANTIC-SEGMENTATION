"""Check Dice behavior and the non-destructive nested-path resolver."""
import json
from pathlib import Path
import tempfile
import unittest
import torch

from data import dice_loss as loss_fn
from resolve_paths import resolve_paths
from make_notebook import build_notebook


class DiceTests(unittest.TestCase):
    def test_balanced_uniform_predictions(self):
        logits = torch.zeros(1, 6, 1, 6, requires_grad=True)
        target = torch.arange(6).reshape(1, 1, 6)
        self.assertAlmostEqual(loss_fn(logits, target).item(), 5 / 6, places=5)

    def test_correct_predictions_beat_wrong_predictions(self):
        target = torch.arange(6).reshape(1, 1, 6)
        correct = torch.nn.functional.one_hot(target, 6).permute(0, 3, 1, 2).float() * 30
        wrong = correct.roll(1, dims=1)
        self.assertLess(loss_fn(correct, target).item(), 1e-5)
        self.assertGreater(loss_fn(wrong, target).item(), .99)

    def test_gradient_improves_overlap(self):
        target = torch.arange(6).reshape(1, 1, 6)
        logits = torch.zeros(1, 6, 1, 6, requires_grad=True)
        loss = loss_fn(logits, target)
        loss.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertLess(loss_fn(logits.detach() - logits.grad, target).item(), loss.item())

    def test_auxiliary_head_does_not_change_loss(self):
        logits = torch.randn(1, 6, 1, 6)
        target = torch.arange(6).reshape(1, 1, 6)
        self.assertEqual(loss_fn(logits, target), loss_fn((logits, torch.tensor(float('nan'))), target))

    def test_nested_paths_and_ambiguous_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'nested').mkdir()
            (root / 'nested/a.tif').touch()
            entries = [dict(tile_id='2_10', image='images/a.tif')]
            result = resolve_paths(root, entries)
            self.assertEqual(result['overrides'], {'images/a.tif': 'nested/a.tif'})
            (root / 'other').mkdir()
            (root / 'other/a.tif').touch()
            with self.assertRaisesRegex(ValueError, 'ambiguous'):
                resolve_paths(root, entries)

    def test_excluded_files_need_not_be_present(self):
        with tempfile.TemporaryDirectory() as directory:
            result = resolve_paths(directory, [dict(tile_id='4_12', image='missing.tif')])
            self.assertEqual(result['overrides'], {})

    def test_requested_notebook_filename_matches(self):
        notebook = Path(__file__).with_name('kaggle_demo.ipynb')
        self.assertEqual(json.loads(notebook.read_text(encoding='utf-8')), build_notebook())


if __name__ == '__main__':
    unittest.main()
