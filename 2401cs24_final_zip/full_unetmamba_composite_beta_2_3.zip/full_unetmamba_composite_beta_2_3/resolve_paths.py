"""Resolve nested dataset paths once; never modify the input data or manifest."""
import argparse
import json
import os
from pathlib import Path


def resolve_paths(root, entries):
    root = Path(root).resolve()
    by_name, relative = {}, set()
    for directory, _, names in os.walk(root):
        for name in names:
            if Path(name).suffix.lower() not in ('.tif', '.tiff'):
                continue
            path = Path(directory) / name
            value = path.relative_to(root).as_posix()
            relative.add(value)
            by_name.setdefault(name, []).append(value)
    overrides, problems = {}, []
    for record in entries:
        if record['tile_id'] in ('4_12', '6_7'):
            continue
        for field in ('image', 'mask'):
            value = record.get(field)
            if not value or value in relative:
                continue
            matches = by_name.get(Path(value).name, [])
            if len(matches) != 1:
                problems.append(dict(expected=value, matches=matches))
            else:
                overrides[value] = matches[0]
    if problems:
        raise ValueError('Missing or ambiguous files: ' + json.dumps(problems, indent=2))
    return dict(data_root=str(root), overrides=overrides)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('data', type=Path)
    args = parser.parse_args()
    entries = json.loads((args.data / 'manifest.json').read_text())['tiles']
    print('Indexing TIFF filenames once; no pixel data read...', flush=True)
    result = resolve_paths(args.data, entries)
    output = Path(__file__).with_name('dataset_paths.json')
    output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'Paths checked; {len(result["overrides"])} nested paths resolved. Saved {output}', flush=True)
