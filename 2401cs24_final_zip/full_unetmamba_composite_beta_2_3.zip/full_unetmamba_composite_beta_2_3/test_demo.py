"""Multiclass scoring and streamed prediction checks using synthetic data."""
import ast
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import rasterio
from rasterio.transform import from_origin
import torch
from torch.utils.data import DataLoader

from data import Tiles
from run import evaluate, metrics, predict_tiles, validate_task_config, HERE
from make_notebook import build_notebook


class ConstantBuilding(torch.nn.Module):
    def forward(self, x):
        out = torch.zeros(x.shape[0], 6, *x.shape[-2:])
        out[:, 1] = 10
        return out


class Tests(unittest.TestCase):
    def test_precision_recall_from_confusion(self):
        matrix = np.zeros((6, 6), dtype=np.int64)
        matrix[:2, :2] = [[2, 1], [0, 1]]
        result = metrics(matrix)
        self.assertAlmostEqual(result['mean_precision'], .75)
        self.assertAlmostEqual(result['mean_recall'], 5 / 6)
        self.assertIsNone(result['per_class']['clutter']['precision'])

    def test_notebook_matches_generator_and_compiles(self):
        notebook = json.loads((HERE / "kaggle_demo.ipynb").read_text(encoding="utf-8"))
        self.assertEqual(notebook, build_notebook())
        self.assertEqual(notebook, json.loads((HERE / "kaggle_demo.ipynb").read_text(encoding="utf-8")))
        for index, cell in enumerate(notebook["cells"]):
            if cell["cell_type"] != "code":
                continue
            source = "".join(cell["source"])
            compile(source, f"notebook-cell-{index}", "exec")
            self.assertIsNone(cell["execution_count"])
            self.assertEqual(cell["outputs"], [])
            # Subprocess -c snippets need their own compilation as well.
            for node in ast.walk(ast.parse(source)):
                if isinstance(node, ast.List):
                    for position, element in enumerate(node.elts[:-1]):
                        if (isinstance(element, ast.Constant) and element.value == "-c"
                                and isinstance(node.elts[position + 1], ast.Constant)):
                            snippet = ast.literal_eval(node.elts[position + 1])
                            compile(snippet, f"subprocess-cell-{index}", "exec")

    def test_notebook_training_and_prediction_default_to_disabled(self):
        values = {}
        for cell in build_notebook()["cells"]:
            if cell["cell_type"] != "code":
                continue
            for node in ast.parse("".join(cell["source"])).body:
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id in ("RUN_TRAINING", "RUN_PREDICTION"):
                            values[target.id] = ast.literal_eval(node.value)
        self.assertEqual(values, {"RUN_TRAINING": False, "RUN_PREDICTION": False})

    def test_notebook_uses_kaggle_paths_without_drive(self):
        source = "\n".join("".join(c["source"]) for c in build_notebook()["cells"] if c["cell_type"] == "code")
        self.assertIn("/kaggle/input/", source)
        self.assertIn("/kaggle/working/", source)
        self.assertNotIn("google.colab", source)
        self.assertNotIn("/content/", source)
        # Runtime tests import the generator and verify both generated notebooks.
        for name in ("make_notebook.py", "kaggle_demo.ipynb", "kaggle_demo.ipynb"):
            self.assertIn(repr(name), source)

    def test_task_configuration_matches_implementation(self):
        cfg = json.loads((HERE / "config.json").read_text())
        validate_task_config(cfg)
        for key, value in (("num_classes", 1), ("ignore_index", 0),
                           ("model", "UNetFormer"), ("scan_backend", "automatic"),
                           ("pretrained", True),
                           ("precision", "float16"), ("selection_metric", "loss"),
                           ("input_channels", ["nir", "red", "green"]),
                           ("prediction_split", "train"), ("learning_rate", -1)):
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_task_config(dict(cfg, **{key: value}))

    def test_ignored_pixels_do_not_enter_metrics(self):
        target = torch.tensor([[0, 1], [1, 255]])
        prediction = torch.tensor([[0, 0], [1, 5]])
        logits = torch.nn.functional.one_hot(prediction, 6).permute(2, 0, 1).float() * 10
        def score(x):
            return evaluate(torch.nn.Identity(), DataLoader([dict(image=x, mask=target)]), torch.device("cpu"))
        result = score(logits)
        self.assertEqual(result["valid_pixels"], 3)
        self.assertEqual(result["confusion_matrix"][1][:2], [1, 1])
        self.assertAlmostEqual(result["mean_iou"], .5)
        self.assertAlmostEqual(result["pixel_accuracy"], 2 / 3)
        self.assertIsNone(result["per_class"]["clutter"]["iou"])
        logits[:, 1, 1] = -100
        self.assertEqual(result, score(logits))

    def test_no_labels_has_no_accuracy(self):
        batch = dict(image=torch.zeros(6, 2, 2), mask=torch.full((2, 2), 255))
        result = evaluate(torch.nn.Identity(), DataLoader([batch]), torch.device("cpu"))
        self.assertIsNone(result["loss"])
        self.assertIsNone(result["mean_iou"])
        self.assertEqual(result["valid_pixels"], 0)

    def test_false_positive_absent_class_is_included(self):
        matrix = np.zeros((6, 6), dtype=np.int64)
        matrix[0, 5] = 3
        result = metrics(matrix)
        self.assertEqual(result["per_class"]["clutter"]["iou"], 0)
        self.assertEqual(result["mean_iou"], 0)

    def test_nonfinite_predictions_rejected(self):
        batch = dict(image=torch.full((6, 2, 2), float("nan")), mask=torch.zeros(2, 2).long())
        with self.assertRaises(FloatingPointError):
            evaluate(torch.nn.Identity(), DataLoader([batch]), torch.device("cpu"))

    def test_stitching_georeference_padding_nodata_and_unlabeled_tile(self):
        with tempfile.TemporaryDirectory(prefix="potsdam_predict_") as folder:
            root = Path(folder)
            transform = from_origin(100, 200, .05, .05)
            entries = []
            for tid, labeled in (("2_13", True), ("2_14", False)):
                image = f"top_potsdam_{tid}_RGB.tif"
                with rasterio.open(root / image, "w", driver="GTiff", width=7, height=5,
                                   count=3, dtype="uint8", transform=transform, crs="EPSG:32633") as dst:
                    dst.write(np.full((3, 5, 7), 100, dtype=np.uint8))
                    valid = np.full((5, 7), 255, dtype=np.uint8)
                    valid[0, 0] = 0
                    dst.write_mask(valid)
                entry = dict(tile_id=tid, split="test", image=image)
                if labeled:
                    mask = f"top_potsdam_{tid}_label.tif"
                    with rasterio.open(root / mask, "w", driver="GTiff", width=7, height=5,
                                       count=1, dtype="uint8", transform=transform, crs="EPSG:32633") as dst:
                        values = np.ones((1, 5, 7), dtype=np.uint8)
                        values[0, 1, 1] = 255
                        dst.write(values)
                    entry.update(mask=mask, label_encoding="class_ids")
                entries.append(entry)
            (root / "manifest.json").write_text(json.dumps(dict(tiles=entries)), encoding="utf-8")
            dataset = Tiles(root, split="test", patch_size=4)
            result = predict_tiles(ConstantBuilding(), dataset, torch.device("cpu"), root / "out", batch_size=3)
            self.assertEqual(result["overall"]["valid_pixels"], 33)
            self.assertEqual(result["overall"]["mean_iou"], 1)
            self.assertIsNone(result["per_tile"]["2_14"]["mean_iou"])
            for path in result["files"].values():
                with rasterio.open(path) as src:
                    values = src.read(1)
                    self.assertEqual(values.shape, (5, 7))
                    self.assertEqual(src.transform, transform)
                    self.assertEqual(src.crs.to_epsg(), 32633)
                    self.assertEqual(src.nodata, 255)
                    self.assertEqual(values[0, 0], 255)
                    self.assertEqual(values[1, 1], 1)  # Ignored GT must not erase predictions.
                    self.assertEqual(int((values == 1).sum()), 34)
            with self.assertRaises(FileExistsError):
                predict_tiles(ConstantBuilding(), dataset, torch.device("cpu"), root / "out")


if __name__ == "__main__":
    unittest.main()
