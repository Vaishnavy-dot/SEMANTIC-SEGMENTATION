"""Six-class RGB UNetMamba with an explicitly selected scan backend."""
from mamba_backend import load_mamba


def build_model(*, use_pretrained=False, backend='cuda'):
    if use_pretrained:
        raise ValueError('This test package uses random initialization; set pretrained=false')
    if backend not in ('cuda', 'reference'):
        raise ValueError('Choose cuda or reference explicitly')
    module = load_mamba(backend)
    # Upstream pretrained=False alone does not prevent loading rest_lite.pth.
    return module.UNetMamba(pretrained=False, backbone_path=None, num_classes=6)


def main_logits(output):
    return output[0] if isinstance(output, (tuple, list)) else output
