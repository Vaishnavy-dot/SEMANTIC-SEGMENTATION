"""Synthetic raster checks; no downloaded Potsdam data or GPU required."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import rasterio
from rasterio.transform import from_origin
import torch
from torch.utils.data import DataLoader

from data import Tiles, PALETTE, decode_mask, loss_fn


class PotsdamDataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="potsdam_loader_")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.ids = (np.arange(35).reshape(5, 7) % 6).astype(np.uint8)
        self.rgb = PALETTE[self.ids].transpose(2, 0, 1)
        self.write("top_potsdam_2_10_RGB.tif", self.rgb)
        self.write("top_potsdam_2_10_label.tif", self.rgb)
        self.record = dict(tile_id="02_10", split="train",
                           image="top_potsdam_2_10_RGB.tif", mask="top_potsdam_2_10_label.tif")
        self.manifest([self.record])

    def write(self, name, values, transform=None):
        with rasterio.open(self.root / name, "w", driver="GTiff", width=values.shape[2],
                           height=values.shape[1], count=values.shape[0], dtype="uint8",
                           crs="EPSG:32633", transform=transform or from_origin(100, 200, .05, .05)) as dst:
            dst.write(values)

    def manifest(self, records):
        (self.root / "manifest.json").write_text(json.dumps(dict(tiles=records)), encoding="utf-8")

    def test_palette_and_unknown_colors(self):
        np.testing.assert_array_equal(decode_mask(self.rgb), self.ids)
        values = self.rgb.copy()
        values[:, 0, 0] = 0
        with self.assertRaises(ValueError):
            decode_mask(values)
        self.assertEqual(decode_mask(values, ignore_black=True)[0, 0], 255)
        values[:, 0, 0] = 42
        with self.assertRaises(ValueError):
            decode_mask(values, ignore_black=True)
        np.testing.assert_array_equal(decode_mask(self.ids[None], encoding="class_ids"), self.ids)

    def test_patches_reconstruct_without_counting_padding(self):
        dataset = Tiles(self.root, patch_size=4, mean=(0, 0, 0), std=(1, 1, 1))
        self.assertEqual(len(dataset), 4)
        restored = np.full((5, 7), 255, dtype=np.uint8)
        total = 0
        for sample in dataset:
            h, w, r, c = (sample[k] for k in ("valid_height", "valid_width", "row", "col"))
            mask = sample["mask"].numpy()
            restored[r:r+h, c:c+w] = mask[:h, :w]
            total += int((mask != 255).sum())
            self.assertTrue((mask[h:, :] == 255).all())
            self.assertTrue((mask[:, w:] == 255).all())
            np.testing.assert_allclose(sample["image"][:, :h, :w],
                                       self.rgb[:, r:r+h, c:c+w] / 255., atol=1e-7)
        np.testing.assert_array_equal(restored, self.ids)
        self.assertEqual(total, 35)
        batch = next(iter(DataLoader(dataset, batch_size=2)))
        self.assertEqual(tuple(batch["image"].shape), (2, 3, 4, 4))

    def test_duplicate_tile_and_path_escape_rejected(self):
        self.manifest([self.record, dict(self.record, tile_id="2_10", split="test")])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            Tiles(self.root)
        self.manifest([dict(self.record, image="../outside.tif")])
        with self.assertRaisesRegex(ValueError, "escapes"):
            Tiles(self.root)

    def test_other_split_rasters_not_opened(self):
        self.manifest([self.record, dict(tile_id="2_13", split="test", image="missing.tif")])
        self.assertEqual(len(Tiles(self.root, patch_size=4)), 4)

    def test_training_exclusions_do_not_open_missing_files(self):
        excluded = [dict(tile_id=t, split='train', image='absent.tif', mask='absent_mask.tif')
                    for t in ('4_12', '6_7')]
        self.manifest([self.record] + excluded)
        dataset = Tiles(self.root, patch_size=4)
        self.assertEqual(len(dataset.records), 1)
        self.assertEqual(len(dataset), 4)

    def test_transform_mismatch_rejected(self):
        self.write(self.record["mask"], self.rgb, from_origin(101, 200, .05, .05))
        with self.assertRaisesRegex(ValueError, "transform mismatch"):
            Tiles(self.root)

    def test_unlabeled_test_and_no_eval_augmentation(self):
        self.manifest([dict(self.record, split="test", mask=None)])
        sample = Tiles(self.root, split="test", patch_size=4)[0]
        self.assertTrue(bool((sample["mask"] == 255).all()))
        with self.assertRaises(ValueError):
            Tiles(self.root, split="test", augment=True)

    def test_flips_keep_image_and_mask_aligned(self):
        dataset = Tiles(self.root, augment=True, patch_size=4, mean=(0, 0, 0), std=(1, 1, 1))
        with patch("data.random.random", return_value=0.0):
            sample = dataset[0]
        recovered = (sample["image"].numpy() * 255).round().astype(np.uint8)
        np.testing.assert_array_equal(decode_mask(recovered), sample["mask"].numpy())

    def test_dice_ignores_padding(self):
        logits = torch.randn(1, 6, 2, 2, requires_grad=True)
        targets = torch.tensor([[[0, 1], [5, 255]]])
        loss = loss_fn(logits, targets)
        changed = logits.detach().clone()
        changed[:, :, 1, 1] = 1000
        self.assertAlmostEqual(loss.item(), loss_fn(changed, targets).item())
        loss.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertEqual(logits.grad[:, :, 1, 1].abs().sum().item(), 0)
        with self.assertRaisesRegex(ValueError, "No supervised"):
            loss_fn(logits, torch.full_like(targets, 255))


if __name__ == "__main__":
    unittest.main()
