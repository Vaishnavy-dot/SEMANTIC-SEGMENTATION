"""Build the official core extension inside the writable Kaggle code copy."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def main():
    here = Path(__file__).resolve().parent
    logs = here / 'setup_logs'
    logs.mkdir(exist_ok=True)
    record = dict(python=sys.version, status='started')
    try:
        import torch
        from torch.utils.cpp_extension import CUDA_HOME
        record.update(torch=torch.__version__, cuda=torch.version.cuda, cuda_home=str(CUDA_HOME))
        if sys.platform != 'linux' or not torch.cuda.is_available():
            raise RuntimeError('Enable a Kaggle GPU before building the CUDA extension.')
        if CUDA_HOME is None or not (Path(CUDA_HOME) / 'bin/nvcc').is_file():
            raise RuntimeError('CUDA compiler nvcc is required in the Kaggle runtime.')
        record['gpu'] = torch.cuda.get_device_name(0)
        source = here / 'vendor/UNetMamba/unetmamba_model/kernels/selective_scan'
        build = here / 'build/selective_scan'
        shutil.copytree(source, build, dirs_exist_ok=True)
        # CUDA 13 / CCCL 3 removed these legacy CUB helpers.
        # Patch the build copy only; retain the vendored upstream source.
        if int(torch.version.cuda.split('.')[0]) >= 13:
            header = build / 'csrc/selective_scan/reverse_scan.cuh'
            code = header.read_text()
            code = code.replace('cub::LaneId()', 'cuda::ptx::get_sreg_laneid()')
            code = code.replace('cub::CTA_SYNC()', '__syncthreads()')
            if '#include <cuda/ptx>' not in code:
                code = '#include <cuda/ptx>\n' + code
            header.write_text(code)
            record['cub_compatibility_patch'] = 'LaneId and CTA_SYNC migrated to supported CUDA APIs'
        setup = build / 'setup.py' 
        text = setup.read_text()
        marker = 'MODES = ["core", "ndstate", "oflex"]'
        if marker not in text:
            raise RuntimeError('Unexpected upstream setup.py; inspect source version.')
        text = text.replace(marker, 'MODES = ["core"]', 1)
        # Build for the assigned GPU rather than upstream's fixed 70/80/90 list.
        start = text.index('    cc_flag.append("-gencode")')
        end = text.index('    # HACK:', start)
        major, minor = torch.cuda.get_device_capability(0)
        arch = f'{major}{minor}'
        text = text[:start] + f'    cc_flag = ["-gencode", "arch=compute_{arch},code=sm_{arch}"]\n\n' + text[end:]
        # Follow the installed headers if they explicitly require C++20.
        include = Path(torch.__file__).parent / 'include'
        headers = [include / 'c10/util/C++17.h', include / 'torch/csrc/api/include/torch/all.h']
        requires_cpp20 = any('C++20' in line and '#error' in line
                             for header in headers if header.is_file()
                             for line in header.read_text().splitlines())
        if requires_cpp20:
            text = text.replace('-std=c++17', '-std=c++20')
        setup.write_text(text)
        command = [sys.executable, '-m', 'pip', 'install', '--no-build-isolation', '--no-deps', '-v', str(build)]
        record['command'] = command
        started = time.perf_counter()
        print('Building selective_scan_cuda_core; log:', logs / 'selective_scan_build.log', flush=True)
        with (logs / 'selective_scan_build.log').open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                    env={**os.environ, 'MAX_JOBS': '2'})
        record.update(seconds=time.perf_counter() - started, returncode=result.returncode)
        if result.returncode:
            lines = (logs / 'selective_scan_build.log').read_text(errors='replace').splitlines()
            print('\n--- Build log (last 60 lines) ---\n' + '\n'.join(lines[-60:]), flush=True)
            raise RuntimeError(f'CUDA build failed. Read {logs / "selective_scan_build.log"}; no automatic fallback.')
        subprocess.run([sys.executable, '-c', 'import torch; import selective_scan_cuda_core'], check=True)
        record['status'] = 'built_and_imported; run check_scan.py --cuda next'
    except Exception as exc:
        record.update(status='failed', error=str(exc))
        raise
    finally:
        (logs / 'install.json').write_text(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
