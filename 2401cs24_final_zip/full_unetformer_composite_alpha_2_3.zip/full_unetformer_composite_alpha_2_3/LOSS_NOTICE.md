# Lovasz-Softmax attribution

Reference: Maxim Berman, Amal Rannen Triki and Matthew B. Blaschko,
"The Lovasz-Softmax loss: A tractable surrogate for the optimization of the
intersection-over-union measure in neural networks", CVPR 2018.

Implementation reference: https://github.com/bermanmaxim/LovaszSoftmax

This package adapts the multiclass sorted-error objective for six-class logits,
valid-pixel masking, main-head-only supervision and modern PyTorch autograd.
It averages classes present in the pooled batch, not individual images, and
rejects fully ignored batches consistently with the other experiment runners.
The loss implementation notice below does not replace the separately included
UNetFormer vendor license.

MIT License

Copyright (c) 2018 Maxim Berman

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
