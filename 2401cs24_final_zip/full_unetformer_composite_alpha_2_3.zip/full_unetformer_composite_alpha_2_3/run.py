"""Smoke-test, train and predict six-class Potsdam RGB segmentation.

Requires --data or config data_root with the manifest documented in
data.py. Training opens train/validation only; predict defaults to test.
--checkpoint restores weights for inference or a fresh training run, not resume.
"""
import argparse
import hashlib
import json
import os
import random
import time
from pathlib import Path

import numpy as np
import rasterio
from rasterio.windows import Window
import torch
from torch.utils.data import DataLoader

from data import Tiles, loss_fn, CLASS_NAMES, PALETTE, NUM_CLASSES, IGNORE_INDEX, LABEL
from model import build_model, main_logits

HERE = Path(__file__).resolve().parent


def validate_task_config(cfg):
    """Reject task switches the current RGB runner does not implement."""
    supported = dict(model="UNetFormer", dataset="Potsdam", input_channels=["red", "green", "blue"],
                     num_classes=NUM_CLASSES, class_names=list(CLASS_NAMES),
                     ignore_index=IGNORE_INDEX, loss="main_head_brier_lovasz_alpha_2_3",
                     selection_metric="mean_iou", include_clutter_in_mean=True,
                     precision="float32")
    if cfg.get('excluded_training_tiles') != ['4_12', '6_7']:
        raise ValueError('This experiment requires exclusions 4_12 and 6_7')
    if cfg.get('brier_reduction') != 'sum_classes_mean_valid_pixels' or cfg.get('pretrained') is not False:
        raise ValueError('Use brier_reduction=sum_classes_mean_valid_pixels and random initialization')
    if cfg.get('composite_alpha') != 2 / 3 or cfg.get('composite_brier_weight') != 1 / 3:
        raise ValueError('This trial requires alpha=2/3 and Brier weight=1/3')
    if cfg.get('lovasz_classes') != 'present' or cfg.get('lovasz_per_image') is not False:
        raise ValueError('Use pooled present-class Lovasz')
    if cfg.get("scheduler") != "constant":
        raise ValueError("This baseline uses a constant learning rate")
    for key, expected in supported.items():
        if key not in cfg or type(cfg[key]) is not type(expected) or cfg[key] != expected:
            raise ValueError(f"This runner requires {key}={expected!r}")
    if cfg.get("prediction_split") not in ("validation", "test"):
        raise ValueError("prediction_split must be validation or test")
    for key in ("data_root", "output_root"):
        if cfg.get(key) is not None and (not isinstance(cfg[key], str) or not cfg[key].strip()):
            raise ValueError(f"{key} must be a nonempty path string or null")
    if not isinstance(cfg.get("pretrained"), bool):
        raise ValueError("pretrained must be a boolean")
    for key in ("learning_rate", "weight_decay"):
        value = cfg.get(key)
        if (isinstance(value, bool) or not isinstance(value, (int, float)) or
                not np.isfinite(value) or value < 0 or (key == "learning_rate" and value == 0)):
            raise ValueError(f"Invalid {key}")


def metrics(confusion):
    """Rows=reference, columns=prediction; undefined classes excluded from means."""
    confusion = np.asarray(confusion, dtype=np.int64)
    tp = np.diag(confusion)
    truth, predicted = confusion.sum(1), confusion.sum(0)
    union = truth + predicted - tp
    per_class = {}
    for i, name in enumerate(CLASS_NAMES):
        per_class[name] = dict(
            iou=float(tp[i] / union[i]) if union[i] else None,
            f1=float(2 * tp[i] / (truth[i] + predicted[i])) if truth[i] + predicted[i] else None,
            reference_pixels=int(truth[i]), predicted_pixels=int(predicted[i]))
    ious = [v["iou"] for v in per_class.values() if v["iou"] is not None]
    f1s = [v["f1"] for v in per_class.values() if v["f1"] is not None]
    for i, name in enumerate(CLASS_NAMES):
        per_class[name]["precision"] = float(tp[i] / predicted[i]) if predicted[i] else None
        per_class[name]["recall"] = float(tp[i] / truth[i]) if truth[i] else None
    precisions = [v["precision"] for v in per_class.values() if v["precision"] is not None]
    recalls = [v["recall"] for v in per_class.values() if v["recall"] is not None]
    count = int(confusion.sum())
    return dict(confusion_matrix=confusion.tolist(), valid_pixels=count, per_class=per_class,
                mean_precision=float(np.mean(precisions)) if precisions else None,
                mean_recall=float(np.mean(recalls)) if recalls else None,
                mean_iou=float(np.mean(ious)) if ious else None,
                mean_f1=float(np.mean(f1s)) if f1s else None,
                pixel_accuracy=float(tp.sum() / count) if count else None,
                averaging="All six classes including clutter; undefined classes excluded")


def add_confusion(confusion, prediction, target):
    valid = target != IGNORE_INDEX
    pairs = NUM_CLASSES * target[valid] + prediction[valid]
    confusion += torch.bincount(pairs, minlength=NUM_CLASSES ** 2).reshape(
        NUM_CLASSES, NUM_CLASSES).cpu().numpy()


def checked_logits(model, images):
    logits = main_logits(model(images))
    if logits.shape != (images.shape[0], NUM_CLASSES, *images.shape[-2:]):
        raise ValueError("Model must return [B,6,H,W]")
    if not bool(torch.isfinite(logits).all()):
        raise FloatingPointError("Nonfinite model output")
    return logits


def evaluate(model, loader, device):
    model.eval()
    total, pixels = 0.0, 0
    confusion = np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=np.int64)
    with torch.inference_mode():
        for batch in loader:
            x, y = batch["image"].to(device), batch["mask"].to(device)
            logits = checked_logits(model, x)
            count = int((y != IGNORE_INDEX).sum())
            if count:
                total += float(loss_fn(logits, y)) * count
                pixels += count
                add_confusion(confusion, logits.argmax(1), y)
    return dict(loss=total / pixels if pixels else None, **metrics(confusion))


def colorize(mask):
    colors = np.full((*mask.shape, 3), 128, dtype=np.uint8)
    valid = mask != IGNORE_INDEX
    colors[valid] = PALETTE[mask[valid]]
    return colors


def panel(model, dataset, device, out, label):
    os.environ["MPLBACKEND"] = "Agg"
    os.environ["MPLCONFIGDIR"] = str(out / "mplconfig")
    import matplotlib
    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    model.eval()
    sample = dataset[0]
    h, w = sample["valid_height"], sample["valid_width"]
    x = sample["image"]
    with torch.inference_mode():
        prediction = checked_logits(model, x[None].to(device)).argmax(1)[0].cpu().numpy()[:h, :w]
    mask = sample["mask"].numpy()[:h, :w]
    rgb = np.clip(x.numpy()[:, :h, :w] * dataset.std[:, None, None] +
                  dataset.mean[:, None, None], 0, 1).transpose(1, 2, 0)
    np.savez_compressed(out / "example_prediction.npz", prediction=prediction.astype("uint8"),
                        mask=mask, tile_id=sample["tile_id"], row=sample["row"], col=sample["col"])
    fig, axs = plt.subplots(1, 3, figsize=(12, 4))
    for ax, values, title in zip(axs, (rgb, colorize(mask), colorize(prediction)),
                                 ("RGB", "Reference (gray = ignored/unlabeled)", "Prediction")):
        ax.imshow(values)
        ax.set_title(title)
        ax.axis("off")
    fig.suptitle(f"{label}\nTile {sample['tile_id']}, row {sample['row']}, col {sample['col']}")
    fig.legend(handles=[Patch(facecolor=color / 255, edgecolor="black", label=name)
                        for name, color in zip(CLASS_NAMES, PALETTE)], loc="lower center", ncol=3)
    fig.tight_layout(rect=(0, .12, 1, .9))
    fig.savefig(out / "example.png", dpi=130)
    plt.close(fig)


def predict_tiles(model, dataset, device, out, batch_size=2, num_workers=0):
    """Stream non-overlapping predictions into one class-ID GeoTIFF per tile.

    Preserve source georeferencing and image nodata. Ground-truth ignored pixels
    affect scoring only, never the exported predictions. Padding is discarded.
    """
    if dataset.augment:
        raise ValueError("Prediction dataset must not be augmented")
    # Require exactly the default non-overlapping patch lattice.
    expected = [(i, r, c) for i, rec in enumerate(dataset.records)
                for r in range(0, rec["height"], dataset.patch_size)
                for c in range(0, rec["width"], dataset.patch_size)]
    if dataset.patches != expected:
        raise ValueError("Stitching requires the non-overlapping ordered patch grid")
    records = {r["tile_id"]: r for r in dataset.records}
    out.mkdir(parents=True, exist_ok=True)
    paths = {tid: out / f"top_potsdam_{tid}_prediction.tif" for tid in records}
    if any(path.exists() for path in paths.values()):
        raise FileExistsError("Prediction files already exist; choose a new output directory")
    matrices = {tid: np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=np.int64) for tid in records}
    confusion = np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=np.int64)
    model.eval()
    dst = src = None
    active = None
    try:
        with torch.inference_mode():
            for batch in DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers):
                prediction = checked_logits(model, batch["image"].to(device)).argmax(1).cpu()
                for i, tid in enumerate(batch["tile_id"]):
                    if active != tid:
                        if dst is not None:
                            dst.close()
                            src.close()
                        active = tid
                        src = rasterio.open(records[tid]["image"])
                        dst = rasterio.open(paths[tid], "w", driver="GTiff", width=src.width,
                                            height=src.height, count=1, dtype="uint8", nodata=IGNORE_INDEX,
                                            crs=src.crs, transform=src.transform, compress="deflate")
                        dst.write_colormap(1, {**{j: tuple(map(int, color)) for j, color in enumerate(PALETTE)},
                                               IGNORE_INDEX: (128, 128, 128)})
                        dst.update_tags(classes=json.dumps(dict(enumerate(CLASS_NAMES))), tile_id=tid)
                    h, w, row, col = (int(batch[k][i]) for k in ("valid_height", "valid_width", "row", "col"))
                    window = Window(col, row, w, h)
                    values = prediction[i, :h, :w].numpy().astype("uint8")
                    values[~np.all(src.read_masks(window=window) > 0, axis=0)] = IGNORE_INDEX
                    dst.write(values, 1, window=window)
                    add_confusion(matrices[tid], prediction[i], batch["mask"][i])
    finally:
        if dst is not None:
            dst.close()
        if src is not None:
            src.close()
    for matrix in matrices.values():
        confusion += matrix
    return dict(files={tid: str(path) for tid, path in paths.items()},
                overall=metrics(confusion), per_tile={tid: metrics(m) for tid, m in matrices.items()})


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["smoke", "train", "predict"])
    p.add_argument("--data", type=Path, help="Potsdam root containing manifest.json; overrides config data_root")
    p.add_argument("--config", type=Path, default=HERE / "config.json")
    p.add_argument("--device", choices=["cpu", "cuda", "auto"], default="auto")
    p.add_argument("--epochs", type=int)
    p.add_argument("--batch-size", type=int)
    p.add_argument("--patch-size", type=int)
    p.add_argument("--pretrained", action=argparse.BooleanOptionalAction, default=None)
    p.add_argument("--checkpoint", type=Path, help="Trusted checkpoint; weights only, not training resume")
    p.add_argument("--output", type=Path)
    p.add_argument("--split", choices=["validation", "test"], help="Overrides config prediction_split")
    a = p.parse_args()
    cfg = json.loads(a.config.read_text(encoding="utf-8"))
    for key in ("epochs", "batch_size", "patch_size", "pretrained"):
        value = getattr(a, key)
        if value is not None:
            cfg[key] = value
    try:
        validate_task_config(cfg)
    except ValueError as error:
        p.error(str(error))
    # Config paths are relative to the config file; CLI paths are relative to cwd.
    if a.data is None:
        if cfg.get("data_root") is None:
            p.error("Supply --data or set data_root in the config")
        a.data = (a.config.resolve().parent / cfg["data_root"]).resolve()
    if a.split is None:
        a.split = cfg["prediction_split"]
    for key in ("epochs", "batch_size", "patch_size", "cpu_threads"):
        if not isinstance(cfg[key], int) or cfg[key] < 1:
            p.error(f"{key} must be a positive integer")
    if cfg["patch_size"] % 32:
        p.error("patch_size must be a multiple of 32 for this model")
    if not isinstance(cfg["num_workers"], int) or cfg["num_workers"] < 0:
        p.error("num_workers must be a nonnegative integer")
    if a.mode == "predict" and not a.checkpoint:
        p.error("predict requires --checkpoint")
    output_root = ((a.config.resolve().parent / cfg["output_root"]).resolve()
                   if cfg.get("output_root") is not None else HERE / "outputs")
    out = (a.output or output_root / f"potsdam_{a.mode}").resolve()
    if out.exists() and any(out.iterdir()):
        p.error("Output directory is not empty; select a new run directory")
    if out == a.data.resolve() or a.data.resolve().is_relative_to(out):
        p.error("Output cannot be the data root or its ancestor")
    device = torch.device("cuda" if a.device == "auto" and torch.cuda.is_available()
                          else "cpu" if a.device == "auto" else a.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        p.error("CUDA unavailable; enable GPU or choose CPU")
    random.seed(cfg["seed"])
    np.random.seed(cfg["seed"])
    torch.manual_seed(cfg["seed"])
    torch.set_num_threads(cfg["cpu_threads"])
    manifest_hash = hashlib.sha256((a.data / "manifest.json").read_bytes()).hexdigest()
    if manifest_hash != cfg["required_manifest_sha256"]:
        raise ValueError("Use the frozen final_dataset manifest, not the pilot dataset")
    if a.mode == 'train' and a.checkpoint:
        raise ValueError('Train Brier from fresh initialization; do not fine-tune a CE checkpoint')
    checkpoint = torch.load(a.checkpoint, map_location="cpu", weights_only=True) if a.checkpoint else None
    if checkpoint and checkpoint.get("config", {}).get("model") != "UNetFormer":
        raise ValueError("Checkpoint architecture differs")
    if checkpoint:
        if checkpoint.get("manifest_sha256") != manifest_hash:
            raise ValueError("Checkpoint data/split manifest differs")
        if checkpoint.get("class_names") != list(CLASS_NAMES):
            raise ValueError("Checkpoint class mapping differs (Toronto checkpoints are incompatible)")
        for key in ("mean", "std", "patch_size", "loss", "excluded_training_tiles"):
            if checkpoint["config"][key] != cfg[key]:
                raise ValueError(f"Checkpoint preprocessing differs: {key}")
    model = build_model(use_pretrained=cfg["pretrained"] if checkpoint is None else False).to(device)
    if checkpoint:
        model.load_state_dict(checkpoint["model"])
    data_options = dict(patch_size=cfg["patch_size"], mean=cfg["mean"], std=cfg["std"])
    report = dict(label=LABEL, mode=a.mode, device=str(device), torch=str(torch.__version__), config=cfg,
                  class_names=list(CLASS_NAMES), ignore_index=IGNORE_INDEX,
                  parameters=sum(t.numel() for t in model.parameters()),
                  trainable_parameters=sum(t.numel() for t in model.parameters() if t.requires_grad), manifest_sha256=manifest_hash,
                  initialization="checkpoint" if checkpoint else "pretrained_encoder" if cfg["pretrained"] else "random",
                  recipe="Float32; main-head (1/3) Brier + (2/3) Lovasz loss only; no auxiliary loss")
    out.mkdir(parents=True, exist_ok=True)
    if a.mode == "predict":
        dataset = Tiles(a.data, split=a.split, **data_options)
        report.update(split=a.split, tiles=len(dataset.records), patches=len(dataset))
        report["prediction"] = predict_tiles(model, dataset, device, out / "predictions",
                                             cfg["batch_size"], cfg["num_workers"])
        panel(model, dataset, device, out, f"Potsdam {a.split}: checkpoint prediction")
    else:
        train = Tiles(a.data, split="train", augment=a.mode == "train", **data_options)
        val = Tiles(a.data, split="validation", **data_options)
        report.update(train_tiles=len(train.records), train_patches=len(train),
                      validation_tiles=len(val.records), validation_patches=len(val), test_tiles_read=0)
        if a.mode == "smoke":
            batch = next(iter(DataLoader(train, batch_size=min(2, len(train)))))
            model.train()
            logits = checked_logits(model, batch["image"].to(device))
            loss = loss_fn(logits, batch["mask"].to(device))
            loss.backward()
            grads = [t.grad for t in model.parameters() if t.grad is not None]
            if not torch.isfinite(loss) or not grads or not all(torch.isfinite(g).all() for g in grads):
                raise FloatingPointError("Smoke check produced nonfinite loss/gradients")
            report.update(loss=float(loss.detach()), output_shape=list(logits.shape),
                          finite_gradients=True, optimizer_steps=0, note="Smoke check is not accuracy evidence")
            panel(model, val, device, out, "Smoke check: no optimizer updates")
        else:
            optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["learning_rate"], weight_decay=cfg["weight_decay"])
            loader = DataLoader(train, batch_size=cfg["batch_size"], shuffle=True, num_workers=cfg["num_workers"])
            validation = DataLoader(val, batch_size=cfg["batch_size"], num_workers=cfg["num_workers"])
            history, best = [], -float("inf")
            for epoch in range(1, cfg["epochs"] + 1):
                if device.type == "cuda": torch.cuda.synchronize(device)
                epoch_start = time.perf_counter()
                model.train()
                total, pixels, skipped = 0.0, 0, 0
                for batch_index, batch in enumerate(loader, 1):
                    x, y = batch["image"].to(device), batch["mask"].to(device)
                    count = int((y != IGNORE_INDEX).sum())
                    if not count:
                        skipped += 1
                        continue
                    optimizer.zero_grad(set_to_none=True)
                    loss = loss_fn(checked_logits(model, x), y)
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Nonfinite training loss")
                    loss.backward()
                    optimizer.step()
                    total += float(loss.detach()) * count
                    pixels += count
                    if batch_index % 100 == 0 or batch_index == len(loader):
                        print(json.dumps(dict(epoch=epoch, batch=batch_index, batches=len(loader),
                                              running_train_loss=total / pixels)), flush=True)
                if not pixels:
                    raise ValueError("Training split has no supervised pixels")
                if device.type == "cuda": torch.cuda.synchronize(device)
                training_seconds = time.perf_counter() - epoch_start
                validation_start = time.perf_counter()
                scores = evaluate(model, validation, device)
                if device.type == "cuda": torch.cuda.synchronize(device)
                validation_seconds = time.perf_counter() - validation_start
                if scores["mean_iou"] is None:
                    raise ValueError("Validation split has no supervised pixels")
                history.append(dict(epoch=epoch, training_seconds=training_seconds, validation_seconds=validation_seconds, train_loss=total / pixels, skipped_batches=skipped, validation=scores))
                print(json.dumps(history[-1]), flush=True)
                improved = scores["mean_iou"] > best
                best = max(best, scores["mean_iou"])
                state = dict(model=model.state_dict(), optimizer=optimizer.state_dict(), epoch=epoch,
                             config=cfg, manifest_sha256=manifest_hash, class_names=list(CLASS_NAMES),
                             label=LABEL, best_mean_iou=best)
                torch.save(state, out / "last.pt")
                if improved:
                    torch.save(state, out / "best.pt")
                (out / "history.json").write_text(json.dumps(history, indent=2), encoding="utf-8")
            report.update(epochs_completed=len(history), selection="Highest validation mean IoU, including clutter",
                          best_mean_iou=best, checkpoint_behavior="Fresh optimizer; no exact resume")
            model.load_state_dict(torch.load(out / "best.pt", map_location=device, weights_only=True)["model"])
            panel(model, val, device, out, "Potsdam: best validation mean-IoU checkpoint")
    (out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
