"""Pinned GeoSeg UNetFormer configured for six-class Potsdam RGB segmentation."""
from vendor.UNetFormer import UNetFormer

def build_model(*, use_pretrained: bool = False):
    """Build a three-channel RGB model with six class logits per pixel.

    Set use_pretrained=True to initialize the encoder with timm's pretrained
    weights, which may require a download. The caller must apply the matching
    RGB normalization. False keeps construction offline with random weights.
    """
    return UNetFormer(num_classes=6, pretrained=use_pretrained)

def main_logits(output):
    # Upstream returns (main, auxiliary) during training, main during evaluation.
    return output[0] if isinstance(output, (tuple, list)) else output
