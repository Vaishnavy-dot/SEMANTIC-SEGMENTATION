import hashlib
from pathlib import Path
import tempfile
import unittest
from find_dataset import find_dataset


class DatasetLocationTests(unittest.TestCase):
    def test_discovery_and_file_override(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            folder = root / 'different-account' / 'dataset'
            folder.mkdir(parents=True)
            manifest = folder / 'manifest.json'
            manifest.write_bytes(b'final split')
            digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
            self.assertEqual(find_dataset(root, digest), folder)
            self.assertEqual(find_dataset(root, digest, manifest), folder)
            self.assertEqual(find_dataset(root, digest, folder), folder)
            with self.assertRaises(ValueError):
                find_dataset(root, 'wrong-hash', folder)
            duplicate = root / 'duplicate'
            duplicate.mkdir()
            (duplicate / 'manifest.json').write_bytes(manifest.read_bytes())
            with self.assertRaises(ValueError):
                find_dataset(root, digest)

    def test_missing_dataset(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'Attach'):
                find_dataset(directory, 'missing')
