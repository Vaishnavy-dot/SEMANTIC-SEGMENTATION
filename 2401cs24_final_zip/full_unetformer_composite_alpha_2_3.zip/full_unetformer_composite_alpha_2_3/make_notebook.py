"""Generate the Potsdam Kaggle notebook; generation never installs or trains."""
import json
from pathlib import Path


def md(text):
    return dict(cell_type="markdown", metadata={}, source=text.splitlines(True))


def code(text):
    return dict(cell_type="code", metadata={}, source=text.splitlines(True), outputs=[], execution_count=None)


def base_notebook():
    cells = [md('''# Potsdam RGB segmentation with UNetFormer on Kaggle
Six classes, RGB only, main-head composite loss. Enable a GPU runtime for training.
This notebook uses the explicit original-tile splits in `manifest.json`; it does
not invent a split or use test data to select checkpoints. Height fusion is not
implemented here. Training and final test prediction are disabled by default.

Before starting, attach the current `full_unetformer_composite_alpha_2_3/` code and Potsdam data as notebook
inputs using your own permitted/private copies. Enable a GPU in notebook settings.
Use the frozen `final_dataset/manifest.json` (18 train / 6 validation / 14 test). Each record contains `tile_id`,
`split`, `image`, and a `mask` for training/validation. Paths are relative to that
root. Choose RGB images and full reference labels initially. Freeze the spatial
split before running; the manifest hash must match when loading a checkpoint.
'''), code('''from pathlib import Path
import datetime
import json
import shutil
import subprocess
import sys
import uuid

# Override these paths explicitly if multiple copies are attached.
def unique_match(paths, label):
    paths = sorted(set(paths))
    if len(paths) != 1:
        raise RuntimeError(f'Expected one {label}, found {paths}. Set its path explicitly.')
    return paths[0]
DEMO_SOURCE = unique_match([p.parent for p in Path('/kaggle/input').rglob('baseline_package.json')
                           if json.loads(p.read_text()).get('package') == 'full_unetformer_composite_alpha_2_3'], 'code package')
import hashlib
DATA_ROOT = unique_match([p.parent for p in Path('/kaggle/input').rglob('manifest.json')
                         if hashlib.sha256(p.read_bytes()).hexdigest() == '31e5fd6ba0e0056ea484ae52b985080403ba36d92c8b40dc00a66bbeeb07819e'
                         and (p.parent / '2_Ortho_RGB').is_dir()
                         and (p.parent / '5_Labels_all').is_dir()], 'full Potsdam dataset')
OUTPUT_ROOT = Path('/kaggle/working/full_unetformer_composite_alpha_2_3_runs')
WORK = Path('/kaggle/working/full_unetformer_composite_alpha_2_3')

assert (DEMO_SOURCE / 'run.py').is_file(), DEMO_SOURCE
assert (DATA_ROOT / 'manifest.json').is_file(), 'Create the Potsdam manifest first.'
# Copy only runnable code; leave large datasets and historical outputs in place.
WORK.mkdir(parents=True, exist_ok=True)
for name in ('run.py', 'model.py', 'data.py', 'config.json', 'requirements.txt',
             'test_data.py', 'test_demo.py', 'make_notebook.py',
             'baseline_package.json', 'expected_manifest.json',
             'kaggle_demo.ipynb'):
    shutil.copy2(DEMO_SOURCE / name, WORK / name)
shutil.copytree(DEMO_SOURCE / 'vendor', WORK / 'vendor', dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('__pycache__'))
print('Read-only input data:', DATA_ROOT, '\\nWorking outputs:', OUTPUT_ROOT)
'''), md('''Install dependencies using the runtime's existing PyTorch/torchvision versions
as constraints. This prevents silently replacing its CUDA stack. If the pair is
missing or incompatible, fix the runtime first. Dependency installation and GPU
execution must still be verified in your actual Kaggle session. Enable Internet
for package downloads, or attach a compatible wheel directory and set WHEELHOUSE.
The runner uses one GPU; a second GPU is not automatically used.
'''), code('''from importlib.metadata import version
constraints = WORK / 'runtime_constraints.txt'
constraints.write_text(''.join(f'{name}=={version(name)}\\n'
                               for name in ('torch', 'torchvision')), encoding='utf-8')
WHEELHOUSE = None  # Optional: '/kaggle/input/potsdam-python-wheels'
install_command = [sys.executable, '-m', 'pip', 'install', '-r', str(WORK / 'requirements.txt'),
                   '-c', str(constraints)]
if WHEELHOUSE is not None:
    install_command += ['--no-index', '--find-links', str(WHEELHOUSE)]
subprocess.run(install_command, check=True)
# Fresh subprocess avoids stale notebook imports after package installation.
subprocess.run([sys.executable, '-c',
    "import torch, torchvision, rasterio, timm; "
    "print('torch:', torch.__version__, 'torchvision:', torchvision.__version__); "
    "print('CUDA:', torch.cuda.is_available()); "
    "print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none')"], check=True)
subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(WORK),
                '-p', 'test_*.py'], cwd=WORK, check=True)
'''), md('''Set experiment parameters. Defaults are a 20-epoch full-data baseline, 512-pixel
patches and batch size two, a provisional shared budget, not a tuned training recipe. Change it equally for both models before comparison. Pretrained initialization
may download encoder weights. Current normalization is ImageNet RGB; keep it
consistent with the chosen encoder. No mixed precision or exact resume is implemented.

Data are read in windows directly from `DATA_ROOT`; nothing copies the 28 GB
collection automatically. `/kaggle/input` is read-only: supply the manifest with
the attached data, rather than trying to write it there. Output and copied code
go to `/kaggle/working`. Do not change the split between model comparisons.
Pretrained encoder downloads also need Internet or cached weights; offline
dependency wheels alone do not supply model weights.
'''), code('''EPOCHS = 20
BATCH_SIZE = 2
PATCH_SIZE = 512
USE_PRETRAINED = False
NUM_WORKERS = 0

config = json.loads((WORK / 'config.json').read_text())
config.update(epochs=EPOCHS, batch_size=BATCH_SIZE, patch_size=PATCH_SIZE,
              pretrained=USE_PRETRAINED, num_workers=NUM_WORKERS,
              data_root=str(DATA_ROOT), output_root=str(OUTPUT_ROOT))
CONFIG_PATH = WORK / 'kaggle_config.json'
CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding='utf-8')

def new_output(mode):
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
    return OUTPUT_ROOT / f'{mode}_{stamp}_{uuid.uuid4().hex[:8]}'

def run_demo(mode, output, *extra, config_path=CONFIG_PATH):
    command = [sys.executable, '-B', str(WORK / 'run.py'), mode,
               '--data', str(DATA_ROOT), '--config', str(config_path),
               '--output', str(output), *map(str, extra)]
    subprocess.run(command, cwd=WORK, check=True)
    # Save the run settings beside completed outputs; checkpoints also contain them.
    shutil.copy2(config_path, output / 'run_config.json')
    return json.loads((output / 'report.json').read_text())

# Inspect train/validation only. Merely listing test IDs does not open test rasters.
subprocess.run([sys.executable, '-B', '-c',
    "import json, sys; from data import Tiles; from run import validate_task_config; "
    "c=json.load(open(sys.argv[2])); validate_task_config(c); "
    "sets=[Tiles(sys.argv[1],split=s,patch_size=c['patch_size'],mean=c['mean'],std=c['std']) "
    "for s in ('train','validation')]; "
    "print({s:{'tiles':len(d.records),'patches':len(d)} for s,d in zip(('train','validation'),sets)})",
    str(DATA_ROOT), str(CONFIG_PATH)], cwd=WORK, check=True)
'''), md('''Run the smoke check before training. It executes forward/backward and creates
an RGB/reference/prediction preview with **zero optimizer updates**. Its predictions
are not accuracy evidence. It opens only training and validation data.
'''), code('''from IPython.display import display, Image
SMOKE_DIR = new_output('smoke')
smoke_report = run_demo('smoke', SMOKE_DIR, '--device', 'auto')
print(json.dumps(smoke_report, indent=2))
display(Image(filename=str(SMOKE_DIR / 'example.png')))
'''), md('''Set `RUN_TRAINING=True` when ready. The runner requires CUDA here, opens only
training/validation data, and selects `best.pt` by validation mean IoU including
clutter. Undefined classes are excluded from the mean. `last.pt`, `best.pt` and
`history.json` are written under `/kaggle/working` each epoch. Save a notebook
version with outputs or download the artifacts before ending the session; this
directory is not a mounted persistent Drive. Abrupt termination can interrupt
an active write. Checkpoints do not provide exact training resume.
Each invocation uses a new output directory, so previous runs are not overwritten.
'''), code('''RUN_TRAINING = False
TRAIN_CHECKPOINT = None
if RUN_TRAINING:
    TRAIN_DIR = new_output('train')
    training_report = run_demo('train', TRAIN_DIR, '--device', 'cuda')
    TRAIN_CHECKPOINT = TRAIN_DIR / 'best.pt'
    print(json.dumps(training_report, indent=2))
    print('Best checkpoint:', TRAIN_CHECKPOINT)
    display(Image(filename=str(TRAIN_DIR / 'example.png')))
else:
    print('Training disabled. Set RUN_TRAINING=True to start.')
'''), md('''Run final test prediction only after fixing the experiment using validation.
Set `CHECKPOINT_PATH` to a trusted previous `best.pt`, or leave it as `None` to use
the training result above. The checkpoint's configuration is restored for matching
normalization and patch size. The runner rejects a different manifest/class mapping.

Outputs include one stitched, single-band class-ID GeoTIFF per test tile, a preview,
and pooled/per-tile metrics in `report.json`. Class IDs are 0ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦ÃƒÂ¢Ã¢â€šÂ¬Ã…â€œ5; 255 is nodata.
The number of maps follows your manifest (14 for the historical test partition).
Unlabeled test tiles receive predictions without accuracy scores. No test imagery
or masks are opened by this cell unless `RUN_PREDICTION=True`.
'''), code('''RUN_PREDICTION = False
CHECKPOINT_PATH = None  # Example: '/kaggle/input/my-saved-model/best.pt'
if RUN_PREDICTION:
    checkpoint_path = Path(CHECKPOINT_PATH) if CHECKPOINT_PATH else globals().get('TRAIN_CHECKPOINT')
    assert checkpoint_path is not None and checkpoint_path.is_file(), 'Set CHECKPOINT_PATH to this trial best.pt; find it under /kaggle/working or attach saved outputs. Do not restart training.'
    # Load metadata in a fresh process; never load an untrusted checkpoint.
    PREDICT_CONFIG = WORK / 'predict_config.json'
    subprocess.run([sys.executable, '-c',
        "import json,sys,torch; c=torch.load(sys.argv[1],map_location='cpu',weights_only=True)['config']; "
        "open(sys.argv[2],'w').write(json.dumps(c,indent=2))",
        str(checkpoint_path), str(PREDICT_CONFIG)], check=True)
    PREDICT_DIR = new_output('test')
    prediction_report = run_demo('predict', PREDICT_DIR, '--device', 'cuda',
                                 '--split', 'test', '--checkpoint', checkpoint_path,
                                 config_path=PREDICT_CONFIG)
    print(json.dumps(prediction_report['prediction']['overall'], indent=2))
    print('Prediction GeoTIFFs:', PREDICT_DIR / 'predictions')
    display(Image(filename=str(PREDICT_DIR / 'example.png')))
else:
    print('Test prediction disabled.')
''')]
    for index, cell in enumerate(cells):
        cell["id"] = f"potsdam-{index}"
    return dict(cells=cells, metadata=dict(
        kernelspec=dict(display_name="Python 3", language="python", name="python3"),
        language_info=dict(name="python"), accelerator="GPU"), nbformat=4, nbformat_minor=5)



SETUP_PATHS = "# Set DEMO_SOURCE explicitly to skip code discovery on future sessions.\nDEMO_SOURCE = None  # Example: Path('/kaggle/input/your-code/full_unetformer_composite_alpha_2_3')\nDATA_ROOT = None  # Optional: dataset folder OR full manifest.json path\nif DEMO_SOURCE is None:\n    print('Locating UNetFormer composite alpha=2/3 code package...', flush=True)\n    candidates = []\n    import os\n    for directory, subdirs, files in os.walk('/kaggle/input'):\n        subdirs[:] = [d for d in subdirs if d not in ('vendor', '2_Ortho_RGB', '5_Labels_all')]\n        if 'baseline_package.json' in files:\n            p = Path(directory)\n            if json.loads((p / 'baseline_package.json').read_text()).get('package') == 'full_unetformer_composite_alpha_2_3':\n                candidates.append(p)\n    if len(candidates) != 1:\n        raise RuntimeError(f'Set DEMO_SOURCE explicitly. Matches: {candidates}')\n    DEMO_SOURCE = candidates[0]\nDEMO_SOURCE = Path(DEMO_SOURCE)\nOUTPUT_ROOT = Path('/kaggle/working/full_unetformer_composite_alpha_2_3_runs')\nWORK = Path('/kaggle/working/full_unetformer_composite_alpha_2_3')\nimport importlib.util\nspec = importlib.util.spec_from_file_location('find_dataset', DEMO_SOURCE / 'find_dataset.py')\nresolver = importlib.util.module_from_spec(spec)\nspec.loader.exec_module(resolver)\nexpected_hash = json.loads((DEMO_SOURCE / 'config.json').read_text())['required_manifest_sha256']\nDATA_ROOT = resolver.find_dataset(Path('/kaggle/input'), expected_hash, DATA_ROOT)\nprint('Code:', DEMO_SOURCE, 'Data folder:', DATA_ROOT, flush=True)\n\n"
PATH_CELL = "subprocess.run([sys.executable, '-u', str(WORK / 'resolve_paths.py'), str(DATA_ROOT)],\n               cwd=WORK, check=True)\n"
EXCLUSION_CELL = "import hashlib\nfrom collections import Counter\ncfg = json.loads((WORK / 'config.json').read_text())\nmanifest_bytes = (DATA_ROOT / 'manifest.json').read_bytes()\nassert hashlib.sha256(manifest_bytes).hexdigest() == cfg['required_manifest_sha256'], 'Wrong manifest'\nrecords = json.loads(manifest_bytes)['tiles']\nexcluded = set(cfg['excluded_training_tiles'])\nassert excluded == {'4_12', '6_7'}\nassert all(r['split'] == 'train' for r in records if r['tile_id'] in excluded)\ncounts = dict(Counter(r['split'] for r in records if r['tile_id'] not in excluded))\nassert counts == {'train': 16, 'validation': 6, 'test': 14}, counts\nprint('Excluded training tiles:', sorted(excluded))\nprint('Effective split:', counts)\n(WORK / 'exclusion_report.json').write_text(json.dumps({'excluded': sorted(excluded), 'counts': counts}, indent=2))\n"
LOGGED_RUN = "    output.parent.mkdir(parents=True, exist_ok=True)\n    log_path = output.parent / (output.name + '.log')\n    # Save config before training, even if the process later fails.\n    shutil.copy2(config_path, output.parent / (output.name + '_config.json'))\n    with log_path.open('w', encoding='utf-8') as log:\n        process = subprocess.Popen(command, cwd=WORK, stdout=subprocess.PIPE,\n                                   stderr=subprocess.STDOUT, text=True, errors='replace', bufsize=1)\n        for line in process.stdout:\n            print(line, end='', flush=True)\n            log.write(line)\n            log.flush()\n        returncode = process.wait()\n    if returncode:\n        raise RuntimeError(f'{mode} failed. Read {log_path}; see the error printed above.')\n    for name in ('dataset_paths.json', 'exclusion_report.json'):\n        if (WORK / name).is_file():\n            shutil.copy2(WORK / name, output / name)"

def build_notebook():
    notebook = base_notebook()
    cells = notebook['cells']
    cells[0] = md("""# UNetFormer: composite trial: (1/3) Brier + (2/3) Lovasz
Use the SAME uploaded Potsdam dataset as the completed CE run.
Effective split: 16 train / 6 validation / 14 test; tiles 4_12 and 6_7 are
excluded from training, not deleted. Run cells in order. Start from random
initialization, not the CE checkpoint. Keep test prediction disabled while tuning.
""")
    first = ''.join(cells[1]['source'])
    start = first.index('# Override these paths')
    end = first.index("assert (DEMO_SOURCE / 'run.py')", start)
    first = first[:start] + SETUP_PATHS + first[end:]
    first = first.replace("'baseline_package.json', 'expected_manifest.json',", "'baseline_package.json', 'expected_manifest.json', 'resolve_paths.py', 'find_dataset.py', 'test_dataset_location.py', 'test_composite.py', 'test_brier.py', 'LOSS_NOTICE.md', 'kaggle_demo.ipynb',")
    cells[1] = code(first)
    for cell in cells:
        text = ''.join(cell['source'])
        if cell['cell_type'] == 'code' and 'def run_demo(' in text:
            text = text.replace("    subprocess.run(command, cwd=WORK, check=True)", LOGGED_RUN)
            cell['source'] = text.splitlines(True)
    cells[2:2] = [md('Resolve nested dataset folders once. This checks file names, not test pixel data.'),
                  code(PATH_CELL), md('Confirm the same two training-tile exclusions used in the CE run. No files are deleted.'), code(EXCLUSION_CELL)]
    for i, cell in enumerate(cells):
        if cell['cell_type'] == 'code' and 'SMOKE_DIR = ' in ''.join(cell['source']):
            cells.insert(i, code("""cfg_check = json.loads(CONFIG_PATH.read_text())
assert cfg_check['epochs'] == 20
assert cfg_check['composite_alpha'] == 2 / 3
assert cfg_check['composite_brier_weight'] == 1 / 3
print('Search trial: (1/3) Brier + (2/3) Lovasz; 20 epochs; fresh initialization.')
"""))
            break
    for index, cell in enumerate(cells):
        cell['id'] = f'brier-{index}'
    return notebook


if __name__ == "__main__":
    notebook = build_notebook()
    for index, cell in enumerate(notebook["cells"]):
        if cell["cell_type"] == "code":
            compile("".join(cell["source"]), f"cell-{index}", "exec")
    # Keep the old filename as an identical compatibility copy for existing users.
    for filename in ("kaggle_demo.ipynb",):
        Path(__file__).with_name(filename).write_text(
            json.dumps(notebook, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
