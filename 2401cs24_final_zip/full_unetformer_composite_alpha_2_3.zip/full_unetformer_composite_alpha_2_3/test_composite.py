import json
from pathlib import Path
import unittest
import torch
from data import loss_fn, brier_loss, lovasz_loss
from run import validate_task_config


class CompositeTests(unittest.TestCase):
    def test_known_value_and_gradient(self):
        p = torch.tensor([.8, .4, .2, .6, 0, 0, 0, 0, 0, 0, 0, 0]).reshape(1, 6, 1, 2)
        logits = p.clamp_min(1e-12).log().requires_grad_()
        target = torch.tensor([[[0, 1]]])
        # Brier=.20, Lovasz=.35; weighted sum=.30.
        value = loss_fn(logits, target)
        self.assertAlmostEqual(value.item(), .30, places=6)
        value.backward()
        self.assertTrue(torch.isfinite(logits.grad).all())
        self.assertGreater(logits.grad.abs().sum().item(), 0)

    def test_weight_guard(self):
        cfg = json.loads(Path(__file__).with_name('config.json').read_text())
        validate_task_config(cfg)
        self.assertEqual(cfg['epochs'], 20)
        cfg['composite_alpha'] = 1 / 3
        with self.assertRaises(ValueError):
            validate_task_config(cfg)

    def test_ignored_pixel_has_no_gradient(self):
        logits = torch.randn(1, 6, 1, 3, requires_grad=True)
        target = torch.tensor([[[0, 1, 255]]])
        value = loss_fn(logits, target)
        self.assertTrue(torch.allclose(value, (1 / 3) * brier_loss(logits, target) + (2 / 3) * lovasz_loss(logits, target)))
        value.backward()
        self.assertEqual(logits.grad[..., 2].abs().sum().item(), 0)
