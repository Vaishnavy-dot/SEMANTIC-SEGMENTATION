# UNetFormer composite trial: alpha = 2/3

Loss = (1/3) Brier + (2/3) Lovasz-Softmax. Train for 20 epochs from scratch.
This is one predefined search candidate, not an optimal-weight claim. Compare
validation mIoU with the alpha=1/3 trial and the individual-loss baselines.

Upload this entire folder and attach the existing full Potsdam dataset. Open
kaggle_demo.ipynb (the only notebook) and run cells in order. Enable Internet
for dependency installation and select GPU. Set RUN_TRAINING=True to train.

Included: account-independent manifest discovery, folder/manifest path handling,
nested TIFF resolution, exclusions of 4_12 and 6_7, dependency checks, smoke test,
20-epoch/weight verification, stdout/stderr logs and config saving. Effective
split is 16 train / 6 validation / 14 test. Original dataset files are unchanged.

Settings match the individual UNetFormer trials: seed 20261110, batch 2,
patch 512, AdamW lr=1e-4, weight decay=.01, constant schedule, float32,
random initialization and main-head-only supervision. Brier sums squared
probability errors over classes then averages valid pixels. Lovasz averages
classes present in pooled valid batch pixels. Target 255 is ignored.

Keep RUN_PREDICTION=False while selecting weights. After selection, prediction
uses this trial's best.pt. If notebook variables were lost, set CHECKPOINT_PATH
explicitly to the saved checkpoint. No NameError is raised for a missing
TRAIN_CHECKPOINT variable. Existing checkpoints do not enable exact resume;
rerunning training starts a new experiment.

Keep history.json, report.json, run_config.json, best.pt, last.pt and logs.
The trial config records weights and candidate status. Preserve both candidates'
validation results for automatic selection; this folder does not itself run
the second candidate or claim that a complete search has been performed.
See LOSS_NOTICE.md for Lovasz attribution.
