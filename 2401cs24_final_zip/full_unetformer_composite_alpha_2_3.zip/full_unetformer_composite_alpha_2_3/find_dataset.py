"""Locate the unchanged final manifest without reading image pixels."""
import hashlib
import os
from pathlib import Path


def find_dataset(input_root, expected_hash, override=None):
    def matches(folder):
        manifest = folder / 'manifest.json'
        return manifest.is_file() and hashlib.sha256(manifest.read_bytes()).hexdigest() == expected_hash

    if override is not None:
        folder = Path(override)
        if folder.name == 'manifest.json':
            folder = folder.parent
        if not matches(folder):
            raise ValueError(f'Missing or incorrect final manifest in {folder}. Attach the full Potsdam dataset and check DATA_ROOT.')
        return folder
    candidates = []
    print('Locating full Potsdam dataset by manifest hash...', flush=True)
    for directory, subdirs, files in os.walk(input_root):
        subdirs[:] = [d for d in subdirs if d not in ('vendor', '2_Ortho_RGB', '5_Labels_all')]
        if 'manifest.json' in files and matches(Path(directory)):
            candidates.append(Path(directory))
    if len(candidates) != 1:
        raise ValueError(f'Expected one full dataset; found {candidates}. Attach the existing full Potsdam dataset or set DATA_ROOT explicitly.')
    return candidates[0]
